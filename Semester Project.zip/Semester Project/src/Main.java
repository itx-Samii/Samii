
import java.util.ArrayList;
import java.util.Scanner;

class User{
    String username;
    String password;
    public String login(String a, String b){
    if (username.equals(a) && password.equals(b)) {
        return "Welcome";
    }else{
        return "Wrong data";
    }
    }
}
class Admin extends User{
    Admin(String username, String password){
        this.username= username;
        this.password=password;
    }
}
class Library{
    ArrayList<Book> books =new ArrayList<>();
    ArrayList<Member> Members = new ArrayList<>();
}
class Book extends Library {
    String bookname;
    String authorname;
    String addition;
    String status;

    Book(String bookname, String authorname, String addition) {
        this.bookname = bookname;
        this.authorname = authorname;
        this.addition = addition;
        this.status = "Avilable";
    }
    public void show(){
        System.out.println("Book Name: "+ bookname+  " ,Auothor Name: " + authorname+ " ,Addition: "+ addition+ " ,Status: "+ status);
    }
    public void addbook(String bookname, String authorname, String addition){
        books.add(new Book(bookname,authorname,addition));
        System.out.println(bookname+": Add Successful.");
    }
    public void removebook(String bookname){
        for (Book book : books){
            if (book.bookname.equalsIgnoreCase(bookname)) {
                books.remove(book);
                System.out.println(bookname+": Book removed Successful.");
                return;
            }
        }
    }
    public void showbook(){
        if (books.isEmpty()){
            System.out.println("No Book Found.");
        }else {
            for(Book book : books){
                book.show();
            }
        }
    }
    public void borrowbook(String bookname){
        for(Book book : books){
            if (book.bookname.equalsIgnoreCase(bookname) && book.status.equals("Avilable")){
                book.status= "Borrowed";
                System.out.println(bookname+ ": Bood Borrowed Succesfull.");
                return;
            }
        }
        System.out.println("Book Is Not Avilable For Borrow.");
    }
    public void returnbook(String bookname){
        for (Book book : books){
            if (book.bookname.equalsIgnoreCase(bookname) && book.status.equals("Borrowed")){
                book.status= "Avilable";
                System.out.println(bookname+ ": Book returened.");
                return;
            }
        }
        System.out.println(bookname+ ": Book not Found ");
    }
}
class Member extends Library{
    String name;
    int id;
    int number;
    String email;
    Member(String name,int id, int number, String email){
        this.name=name;
        this.id=id;
        this.number=number;
        this.email=email;
    }



    public void show(){
        System.out.println("Name: "+name+" ,Id: "+id+" ,Phone Number: "+number+" ,Email: "+email);
    }
    public void addmember(String name,int id,int number,String email){
        Members.add(new Member(name,id,number,email));
        System.out.println(name+ ": Member Add Successful");
    }
    public void removemember(String name){
        for (Member member : Members){
            if (member.name.equalsIgnoreCase(name)){
                Members.remove(member);
                System.out.println(name+ ": Member removed");
                return;
            }
        }
        System.out.println("No Member Found.");
    }
    public void showmember(){
        if (Members.isEmpty()){
            System.out.println("No member found.");
        }else {
            for(Member member : Members){
                member.show();
            }
        }
    }
}
public class Main {
    public static void main(String [] args){
        Scanner a = new Scanner(System.in);
        Admin obj = new Admin("samii", "1234");
        Book obj2 = new Book("", "", ""); // dummy values
        Member obj3 = new Member("", 0, 0, ""); // dummy values


        int attemps = 0;
        int login = 0;
        do {
            System.out.println("Enter Your Username:");
            String username = a.nextLine().trim();
            System.out.println("Enter Your Password:");
            String password = a.nextLine().trim();
            if (obj.login(username,password).equals("Welcome")){
                login = 1;
            }else{
                attemps++;
                System.out.println("Wrong User Name Or Password. Attemps left:" +(3-attemps));
            }
        }while (login == 0 && attemps < 3);
        if (login == 0){
            System.out.println(" Too many attemps. Page Close...........");
            return;
        }
        int choice;
                do{
                    System.out.println("Welcome to Library:");
                    System.out.println("1: Add Memnber:");
                    System.out.println("2: Remove Member:");
                    System.out.println("3: Show Member:");
                    System.out.println("4: Add Book:");
                    System.out.println("5: Remove Book:");
                    System.out.println("6: Show Book:");
                    System.out.println("7: Borrow Book");
                    System.out.println("8: Return Book:");
                    System.out.println("9: Exit library:");
                    System.out.println("Enter your choice:");
                    choice = a.nextInt();
                    a.nextLine();
                    switch (choice){
                        case 1:
                            System.out.println("Enter Your Name:");
                            String name = a.nextLine();
                            System.out.println("Enter Your ID:");
                            int id = a.nextInt();
                            a.nextLine();
                            System.out.println("Enter Your Contact number:");
                            int contact = a.nextInt();
                            a.nextLine();
                            System.out.println("Enter Your Email:");
                            String email = a.nextLine();
                            obj3.addmember(name,id,contact,email);
                            break;
                        case 2:
                            System.out.println("Enter Member Name:");
                            name = a.nextLine();
                            obj3.removemember(name);
                            break;
                        case 3:
                            obj3.showmember();
                            break;
                        case 4:
                            System.out.println("Enter Book Name:");
                            String bookname = a.nextLine();
                            System.out.println("Enter Author Name:");
                            String authorname= a.nextLine();
                            System.out.println("Enter Addition:");
                            String addition= a.nextLine();
                            obj2.addbook(bookname,authorname,addition);
                            break;
                        case 5:
                            System.out.println("Enter Book Name to Remove:");
                            bookname= a.nextLine();
                            obj2.removebook(bookname);
                            break;
                        case 6:
                            obj2.showbook();
                            break;
                        case 7:
                            System.out.println("Enter Book Name:");
                            bookname = a.nextLine();
                            obj2.borrowbook(bookname);
                            break;
                        case 8:
                            System.out.println("Enter Book Name:");
                            bookname = a.nextLine();
                            obj2.returnbook(bookname);
                            break;
                        case 9:
                            System.out.println("Eixisting from Library............. Thank you!");
                            break;

                    }
                }while (choice != 9);




    }
}
